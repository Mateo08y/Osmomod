package com.mateo.osmomod.registry;

import com.mateo.osmomod.Osmomod;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ItemRegistry {

    public static final Item SAZONADOR_FILETE = register("sazonador_filete");
    public static final Item SAZONADOR_POLLO = register("sazonador_pollo");
    public static final Item SAZONADOR_PESCADO_Y_MARISCO = register("sazonador_pescado_y_marisco");
    public static final Item SAZONADOR_VERDURAS = register("sazonador_teriyaki");
    public static final Item CUCHILLO_CHEF = register("cuchillo_chef");
    
    // El libro real: Knife Drop
    public static final Item KNIFE_DROP = register("knife_drop");

    private static Item register(String name) {
        return Registry.register(
                Registries.ITEM,
                new Identifier(Osmomod.MOD_ID, name),
                new Item(new Item.Settings())
        );
    }

    public static void registerItems() {
        System.out.println("Items Osmo registrados");
    }
}
