package com.mateo.osmomod;

import net.fabricmc.api.ModInitializer;
import com.mateo.osmomod.registry.ItemRegistry;

public class Osmomod implements ModInitializer {

    public static final String MOD_ID = "osmomod";

    @Override
    public void onInitialize() {
        ItemRegistry.registerItems();
        System.out.println("OSMO MOD cargado correctamente!");
    }
}
